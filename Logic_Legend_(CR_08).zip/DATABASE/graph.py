# import mysql.connector
# import matplotlib.pyplot as plt

# # Connect to MySQL database
# conn = mysql.connector.connect(
#     host="localhost",
#     user="root",
#     password="Sahilgowda2004@",
#     database="client_data"
# )
# cursor = conn.cursor()

# # Query to fetch data from the database
# query = "SELECT age, weight FROM data_of_client"
# cursor.execute(query)
# data = cursor.fetchall()

# # Close the database connection
# cursor.close()
# conn.close()

# # Separate age and weight data
# ages, weights = zip(*data)

# # Plot the graph
# plt.bar(ages, weights)
# plt.title('Age vs Weight for Clients')
# plt.xlabel('Age')
# plt.ylabel('Weight')
# plt.show()



# import mysql.connector
# import matplotlib.pyplot as plt

# # Connect to MySQL database
# conn = mysql.connector.connect(
#     host="localhost",
#     user="root",
#     password="Sahilgowda2004@",
#     database="client_data"
# )
# cursor = conn.cursor()

# # Query to fetch data from the database (assuming you have 'height' column in your table)
# query = "SELECT age, weight, height FROM data_of_client"
# cursor.execute(query)
# data = cursor.fetchall()

# # Close the database connection
# cursor.close()
# conn.close()

# # Calculate BMI
# bmi_data = [(age, weight / (height / 100)**2) for age, weight, height in data]

# # Separate age and BMI data
# ages, bmis = zip(*bmi_data)

# # Plot the bar graph
# plt.bar(ages, bmis, color='green')
# plt.title('Age vs BMI for Clients')
# plt.xlabel('Age')
# plt.ylabel('BMI')
# plt.show()


import mysql.connector
import matplotlib.pyplot as plt

# Connect to MySQL database
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Sahilgowda2004@",
    database="client_data"
)
cursor = conn.cursor()

# Query to fetch data from the database (assuming you have 'height' column in your table)
query = "SELECT age, weight, height FROM data_of_client"
cursor.execute(query)
data = cursor.fetchall()

# Close the database connection
cursor.close()
conn.close()

# Calculate BMI
bmi_data = [(age, weight / (height / 100)**2) for age, weight, height in data]

# Define BMI categories
categories = {
    'Underweight': (0, 18.5),
    'Normal Weight': (18.5, 24.9),
    'Overweight': (25, 29.9),
    'Obese': (30, float('inf'))
}

# Categorize BMI values
category_data = {}
for age, bmi in bmi_data:
    for category, (lower, upper) in categories.items():
        if lower <= bmi < upper:
            if category not in category_data:
                category_data[category] = []
            category_data[category].append((age, bmi))
            break

# Plot the bar graph with different colors for each category
colors = {'Underweight': 'blue', 'Normal Weight': 'green', 'Overweight': 'yellow', 'Obese': 'red'}

for category, data_points in category_data.items():
    ages, bmis = zip(*data_points)
    plt.bar(ages, bmis, color=colors[category], label=category)

plt.title('Age vs BMI for Clients')
plt.xlabel('Age')
plt.ylabel('BMI')
plt.legend()
plt.show()


