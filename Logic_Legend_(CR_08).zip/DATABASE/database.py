import mysql.connector as c

con = c.connect(
    host="localhost",
    user="root",
    password="Sahilgowda2004@",
    database="client_data"
)

while True:
    print("\n1 -> Insert Data\n2 -> Update Weight\n3 -> Delete Record\n4 -> Display Data\n5 -> Exit")
    choice = int(input("Enter your choice: "))

    if choice == 5:
        break

    cursor = con.cursor()

    if choice == 1:
        gym_id = int(input("Enter the new Gym Id: "))
        name = input("Enter your Name: ")
        age = int(input("Enter Your Age: "))
        weight = int(input("Enter Weight: "))
        phone_no = input("Enter your Phone number: ")

        query = "INSERT INTO data_of_client VALUES ({}, '{}', {}, {}, '{}')".format(gym_id, name, age, weight, phone_no)
        cursor.execute(query)
        con.commit()
        print("Data Inserted Successfully")

    elif choice == 2:
        gym_id = int(input("Enter the Gym Id for weight update: "))
        weight = int(input("Enter the new Weight: "))

        query = "UPDATE data_of_client SET weight={} WHERE gym_id={}".format(weight, gym_id)
        cursor.execute(query)
        con.commit()

        if cursor.rowcount > 0:
            print("Weight Updated Successfully")
        else:
            print("No Data Found for this id")

    elif choice == 3:
        gym_id = int(input("Enter the Gym Id for record deletion: "))

        query = "DELETE FROM data_of_client WHERE gym_id = {}".format(gym_id)
        cursor.execute(query)
        con.commit()

        if cursor.rowcount > 0:
            print("Record Deleted Successfully")
        else:
            print("No Data Found for this id")

    elif choice == 4:
        query = "SELECT * FROM data_of_client"
        cursor.execute(query)
        data = cursor.fetchall()

        if data:
            for row in data:
                print(row)
        else:
            print("No data available.")

    else:
        print("Invalid choice. Please enter a valid option.")

cursor.close()
con.close()
