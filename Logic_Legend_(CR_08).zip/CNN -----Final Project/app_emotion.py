from flask import Flask, render_template, Response
import cv2
from keras.models import load_model
from keras.preprocessing.image import img_to_array
import numpy as np

app = Flask(__name__)

# Load the Haar Cascade and Emotion Detection model
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
emotion_model = load_model('model.h5')

# Define emotion labels
emotion_labels = ['Angry', 'Disgust', 'Fear', 'Happy', 'Neutral', 'Sad', 'Surprise']

# OpenCV VideoCapture
cap = cv2.VideoCapture(0)

# Variable to check if "Sad" is detected
sad_detected = False

def detect_emotion(frame):
    global sad_detected

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

    for (x, y, w, h) in faces:
        roi_gray = gray[y:y + h, x:x + w]
        roi_gray = cv2.resize(roi_gray, (48, 48))
        roi = roi_gray.astype('float') / 255.0
        roi = img_to_array(roi)
        roi = np.expand_dims(roi, axis=0)

        # Predict emotion
        preds = emotion_model.predict(roi)[0]
        emotion_label = emotion_labels[preds.argmax()]

        # Draw rectangle and emotion label
        cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)
        cv2.putText(frame, emotion_label, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 0, 0), 2)

        # Check if "Sad" is detected
        if emotion_label == 'Sad':
            sad_detected = True
        else:
            sad_detected = False

    return frame

def generate_frames():
    while True:
        success, frame = cap.read()
        if not success:
            break

        # Perform emotion detection
        frame = detect_emotion(frame)

        # Convert the frame to JPEG format
        _, buffer = cv2.imencode('.jpg', frame)
        frame = buffer.tobytes()

        # Yield the frame in MJPEG format
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

@app.route('/')
def index():
    return render_template('index_emotion_alert.html')

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/check_sad')
def check_sad():
    global sad_detected
    if sad_detected:
        return 'true'
    else:
        return 'false'

if __name__ == "__main__":
    app.run(debug=True)
